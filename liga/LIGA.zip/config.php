<?php
// Datos de conexión a la base de datos
define('DB_HOST', 'localhost'); // Cambia esto si tu servidor MySQL está en otro lugar
define('DB_USER', 'lvuizwgj_liga'); // Reemplaza con tu nombre de usuario de MySQL
define('DB_PASS', 'Joep197085123'); // Reemplaza con tu contraseña de MySQL
define('DB_NAME', 'lvuizwgj_liga');

// Habilitar errores para desarrollo (desactivar en producción)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

define('ROOT_PATH', realpath(dirname(__FILE__)));

// Credenciales del superadministrador (acceso total, no requiere tabla usuarios)
// Cambiar la contraseña por una segura antes de poner en producción
define('SUPERADMIN_USER', 'admin');
define('SUPERADMIN_PASS', '1234');



// Verifica si el usuario actual tiene permiso sobre un torneo
// Superadmin (torneos_permitidos vacío) tiene acceso a todo
function usuarioPuedeTorneo(int $id_torneo): bool {
    if (!isset($_SESSION['admin_autenticado']) || !$_SESSION['admin_autenticado']) return false;
    if (!empty($_SESSION['es_superadmin'])) return true;
    $perms = $_SESSION['torneos_permitidos'] ?? [];
    return empty($perms) || in_array($id_torneo, $perms);
}

// Función para conectar a la base de datos usando PDO
function conectarDB() {
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        return $pdo;
    } catch (\PDOException $e) {
        die("Error de conexión a la base de datos: " . $e->getMessage());
    }
}
?>